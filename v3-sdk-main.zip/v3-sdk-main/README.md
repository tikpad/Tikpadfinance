# Alpha software

The latest version of the SDK is used in production in the Monoswap Interface,
but it is considered Alpha software and may contain bugs or change significantly between patch versions.
If you have questions about how to use the SDK, please reach out in the `#dev-chat` channel of the Discord.
Pull requests welcome!

# Monoswap V3 SDK

In-depth documentation on this SDK is available at monoswap.io
